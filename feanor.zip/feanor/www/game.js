'use strict';
/* Il Giuramento di Fëanor — prototipo (vertical slice)
   Narrativa a scelte + forgia + battaglie a griglia + mappa a nodi. */

const $ = (s, r = document) => r.querySelector(s);
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html !== undefined) e.innerHTML = html; return e; };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------- DATI ---------- */
const MATERIALS = {
  laurelin:  { n: 'Luce di Laurelin',  d: 'Oro vivo',                    atk: 2, hp: 0, mv: 0, corr: 0 },
  telperion: { n: 'Luce di Telperion', d: 'Argento puro',                atk: 0, hp: 6, mv: 0, corr: 0 },
  perla:     { n: 'Perla dei Teleri',  d: 'Sa di sangue',                atk: 0, hp: 2, mv: 1, corr: 1 },
  sangue:    { n: "Sangue d'Orco",     d: 'Corrotto',                    atk: 3, hp: 0, mv: 0, corr: 1 },
  gemma:     { n: 'Gemma di Mithrim',  d: 'Limpida, intatta',            atk: 1, hp: 4, mv: 0, corr: 0 },
  ferro:     { n: 'Ferro di Angband',  d: 'Corrotto',                    atk: 2, hp: 2, mv: 0, corr: 1 },
};
const COMBOS = {
  'laurelin+telperion': { n: 'Luce degli Alberi', atk: 1, hp: 2, mv: 0, corr: 0 },
  'ferro+sangue':       { n: 'Odio condiviso',    atk: 2, hp: 0, mv: 0, corr: 1 },
  'gemma+perla':        { n: 'Mare e cielo',      atk: 0, hp: 0, mv: 1, corr: 0 },
};

const UT = {
  feanor:   { name: 'Fëanor',   g: 'F', team: 'p', hp: 24, atk: 5, mv: 3, rng: 1 },
  maedhros: { name: 'Maedhros', g: 'M', team: 'p', hp: 20, atk: 4, mv: 3, rng: 1 },
  celegorm: { name: 'Celegorm', g: 'C', team: 'p', hp: 14, atk: 4, mv: 3, rng: 2 },
  teleri:   { name: 'Marinaio Teleri', g: 'T', team: 'e', hp: 8,  atk: 2, mv: 3, rng: 1 },
  orco:     { name: 'Orco',     g: 'O', team: 'e', hp: 10, atk: 3, mv: 3, rng: 1 },
  capitano: { name: 'Capitano Orco', g: 'K', team: 'e', hp: 16, atk: 4, mv: 3, rng: 1 },
  gothmog:  { name: 'Gothmog',  g: 'G', team: 'e', hp: 40, atk: 8, mv: 3, rng: 1, boss: true },
};

const BATTLES = {
  alq: {
    rocks: [[2, 3], [3, 3]],
    enemies: [['teleri', 1, 0], ['teleri', 3, 1], ['teleri', 4, 0]],
    reward: 'perla',
  },
  avamposto: {
    rocks: [[1, 3], [4, 3], [2, 1]],
    enemies: [['orco', 1, 0], ['orco', 4, 0], ['capitano', 3, 1]],
    reward: 'ferro',
  },
  accampamento: {
    rocks: [[2, 2], [3, 4]],
    enemies: [['orco', 0, 0], ['orco', 2, 0], ['orco', 5, 1]],
    reward: 'sangue',
  },
  dagor: {
    finale: true,
    rocks: [[0, 3], [5, 3], [2, 3]],
    enemies: [['orco', 1, 0], ['orco', 2, 1], ['orco', 3, 0], ['orco', 4, 1], ['orco', 5, 0]],
  },
};

const MAP_NODES = [
  { id: 'rovine',       name: 'Rovine nel bosco',       desc: 'Qualcosa brilla tra le pietre.',             type: 'scene',  scene: 'rovine' },
  { id: 'accampamento', name: 'Accampamento degli Orchi', desc: 'Battaglia opzionale · Sangue d\'Orco',      type: 'scene',  scene: 'b_accampamento' },
  { id: 'avamposto',    name: 'Avamposto di Angband',   desc: 'Battaglia opzionale · Ferro di Angband',     type: 'scene',  scene: 'b_avamposto' },
  { id: 'campforge',    name: 'Forgia da campo',        desc: 'Fondi i materiali nel Silmaril.',            type: 'scene',  scene: 'campforge', repeat: true },
  { id: 'dagor',        name: 'Dagor-nuin-Giliath',     desc: 'La battaglia sotto le stelle. Scontro finale.', type: 'scene', scene: 'b_dagor', final: true },
];

/* ---------- STATO ---------- */
const SAVE_KEY = 'feanor_save_v1';
const fresh = () => ({ scene: 'intro', inv: { laurelin: 1, telperion: 1 }, sil: { atk: 0, hp: 0, mv: 0 },
  corr: 0, pride: 0, honor: 0, flags: {}, visited: {}, forged: 0 });
let S = load() || fresh();

function load() { try { const j = localStorage.getItem(SAVE_KEY); return j ? JSON.parse(j) : null; } catch (e) { return null; } }
function save() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(S)); } catch (e) { /* ignora */ } }

/* ---------- SCENE NARRATIVE ---------- */
const SCENES = {
  intro: {
    mood: 'gold', title: 'Tirion, Valinor',
    text: 'Nessuno tra gli Eldar plasma come Fëanor, figlio di Finwë. Nella sua fucina, la luce dei Due Alberi, Telperion e Laurelin, attende di essere racchiusa in qualcosa che duri per sempre.\n\nÈ la prima volta che mani elfiche tentano un\'opera simile.',
    choices: [{ t: 'Accendere la forgia', go: 'forge1' }],
  },
  forge1: {
    type: 'forge', mood: 'gold', title: 'La fucina di Fëanor', require: true, next: 'melkor',
    text: 'Scegli due materiali e fondili. Questo è il Silmaril: ogni cosa che gli darai resterà con te.',
  },
  melkor: {
    mood: 'dusk', title: 'Un amico inatteso',
    text: 'Il gioiello brilla più di ogni cosa mai creata. Poi, sulla soglia, compare Melkor, liberato dalla prigionia e vestito di buone maniere.\n\n«Ti ammiro, Fëanor. Peccato che tuo fratello Fingolfin stia già parlando con i Valar per prendere il tuo posto.»',
    choices: [
      { t: 'Ascoltare le sue parole', fx: s => { s.pride += 1; }, go: 'fingolfin' },
      { t: 'Cacciarlo dalla fucina', fx: s => { s.honor += 1; }, go: 'fingolfin' },
    ],
  },
  fingolfin: {
    mood: 'dusk', title: 'Il fratellastro',
    text: 'Fingolfin entra nella sala. Le voci di Melkor hanno già avvelenato l\'aria, e ogni parola di lui ti suona come una minaccia.',
    choices: [
      { t: 'Sguainare la spada', fx: s => { s.pride += 2; s.flags.drew = true; }, go: 'esilio' },
      { t: 'Abbassare lo sguardo e restare fermo', fx: s => { s.honor += 1; }, go: 'esilio' },
    ],
  },
  esilio: {
    mood: 'blood', title: 'Esilio e rovina',
    text: s => (s.flags.drew
      ? 'La punta della tua lama sfiora Fingolfin. I Valar non perdonano: sei esiliato a Formenos.'
      : 'Non hai alzato la spada, ma la tua rabbia era già visibile. I Valar ti mandano a Formenos per placare gli animi.')
      + '\n\nPoi arriva la notizia peggiore: Melkor e Ungoliant hanno distrutto i Due Alberi. Finwë, tuo padre, è morto. I Silmaril sono stati rubati.',
    choices: [{ t: 'Pronunciare il Giuramento', go: 'giuramento' }],
  },
  giuramento: {
    mood: 'blood', title: 'Il Giuramento',
    text: 'Fëanor maledice Melkor e lo chiama Morgoth, il Nemico Oscuro del Mondo. I suoi sette figli sono al suo fianco.\n\nIl Giuramento non si può spezzare: vincolerà ogni Noldo che lo segue, anche quando diventerà ingiusto.',
    choices: [
      { t: 'Giurare con i tuoi figli', fx: s => { s.pride += 1; }, go: 'alqualonde' },
      { t: 'Giurare da solo, sperando di risparmiarli', fx: s => { s.honor += 1; s.flags.alone = true; }, go: 'alqualonde' },
    ],
  },
  alqualonde: {
    mood: 'sea', title: 'Alqualondë',
    text: s => 'Il porto dei Teleri è pieno di navi bianche. Per attraversare il mare e inseguire Morgoth ti servono quelle navi.'
      + (s.flags.alone ? '\n\nI tuoi figli ti seguono comunque: Maedhros è il primo a raggiungerti.' : ''),
    choices: [
      { t: 'Chiedere le navi con rispetto', go: 'teleri_no' },
      { t: 'Prenderle con la forza', fx: s => { s.pride += 1; s.corr += 1; }, go: 'b_alq' },
    ],
  },
  teleri_no: {
    mood: 'sea', title: 'Il rifiuto',
    text: 'I Teleri rifiutano: le navi sono la loro opera, non vi appartengono. Hanno paura di ciò che il Giuramento potrebbe portare.\n\nSe insisti, la tua ragione non cambierà. E tu non hai tempo.',
    choices: [
      { t: 'Implorare ancora', fx: s => { s.honor += 1; }, go: 'teleri_no2' },
      { t: 'Prenderle con la forza', fx: s => { s.pride += 1; s.corr += 1; }, go: 'b_alq' },
    ],
  },
  teleri_no2: {
    mood: 'sea', title: 'Nessuna via',
    text: 'I Teleri non cedono. Le tue parole non bastano, e dietro di te i Noldor si agitano. Il Giuramento li spinge in avanti più di quanto tu stesso riesca a trattenerli.',
    choices: [{ t: 'Prenderle con la forza', fx: s => { s.corr += 1; }, go: 'b_alq' }],
  },
  b_alq: {
    type: 'battle', battle: 'alq', mood: 'sea', title: 'Il primo sangue elfico',
    text: 'I marinai Teleri difendono le loro navi. Non sono guerrieri, ma non vogliono cedere.',
    win: 'navi',
  },
  navi: {
    mood: 'sea', title: 'Le navi',
    text: 'Il porto è silenzioso. Le navi sono vostre. Fingolfin e il suo popolo sono ancora indietro, e sulla riva restano altri Noldor che non sapevano di quello che avete fatto.',
    choices: [
      { t: 'Bruciare le navi dietro di te', fx: s => { s.pride += 2; s.flags.burned = true; }, go: 'map' },
      { t: 'Rimandare le navi a prendere Fingolfin', fx: s => { s.honor += 2; }, go: 'map' },
    ],
  },
  rovine: {
    mood: 'night', title: 'Rovine nel bosco',
    text: 'Tra le pietre di una vecchia torre c\'è qualcosa che luccica, accanto a segni di un rito orchesco.',
    choices: [
      { t: 'Raccogliere la gemma', fx: s => { s.inv.gemma = (s.inv.gemma || 0) + 1; }, go: 'map', visit: 'rovine' },
      { t: 'Lasciar stare tutto', fx: s => { s.honor += 1; }, go: 'map', visit: 'rovine' },
    ],
  },
  campforge: {
    type: 'forge', mood: 'gold', title: 'Forgia da campo', next: 'map',
    text: 'Un fuoco, una pietra piatta e il Silmaril. Qui puoi fondere ciò che hai raccolto.',
  },
  b_accampamento: {
    type: 'battle', battle: 'accampamento', mood: 'ash', title: 'Accampamento degli Orchi',
    text: 'Orchi di Morgoth a guardia di un fuoco. Combattere è facoltativo, ma il loro sangue serve alla forgia.',
    win: 'map', visit: 'accampamento',
  },
  b_avamposto: {
    type: 'battle', battle: 'avamposto', mood: 'ash', title: 'Avamposto di Angband',
    text: 'Un presidio con un capitano. Il ferro che portano è lavorato per uccidere Elfi.',
    win: 'map', visit: 'avamposto',
  },
  b_dagor: {
    type: 'battle', battle: 'dagor', mood: 'night', title: 'Dagor-nuin-Giliath',
    text: 'Gli orchi attaccano sotto le stelle. Non puoi più tornare indietro: dietro di te c\'è solo il mare in fiamme.',
    win: 'morte',
  },
  morte: {
    mood: 'ash', title: 'La fine di Fëanor',
    text: s => {
      let t = s.flags.gothmog
        ? 'Hai abbattuto Gothmog, cosa che nessuno avrebbe creduto possibile. Ma altri Balrog arrivano, e il tuo corpo cede.'
        : 'Gothmog, il Signore dei Balrog, ti ferisce a morte. I tuoi figli ti portano via dal campo.';
      t += '\n\nDalle pendici di Mithrim vedi Thangorodrim in lontananza. Sai che i Noldor da soli non vinceranno. Eppure non ti penti: fai giurare ai figli di mantenere il Giuramento e maledici Morgoth tre volte.\n\nIl tuo spirito brucia così forte che il corpo diventa cenere e fumo.';
      if (s.corr >= 3) t += '\n\nIl Silmaril era carico di cose corrotte. Anche nella morte ti seguì un\'ombra.';
      if (s.pride > s.honor + 2) t += '\n\nIl tuo orgoglio era più grande del tuo onore. Nessuno ricorderà la gentilezza.';
      else if (s.honor >= s.pride) t += '\n\nIn mezzo alla rovina hai provato a fare la cosa giusta. Il Giuramento non te lo permise.';
      t += '\n\nIl Giuramento sopravvive a te, e continua a rovinare i tuoi figli.';
      return t;
    },
    choices: [{ t: 'Ricominciare dall\'inizio', go: 'reset' }],
  },
};

/* ---------- HUD ---------- */
function renderHud() {
  const h = $('#hud');
  h.innerHTML = '';
  const sil = el('div', 'sil', `Silmaril ⚔+${S.sil.atk} ♥+${S.sil.hp} ➜+${S.sil.mv}`);
  const menu = el('button', '', '☰');
  menu.onclick = openMenu;
  h.append(sil, menu);
}

function openOverlay(html, buttons) {
  const o = $('#overlay');
  o.innerHTML = '';
  const box = el('div', 'box', html);
  buttons.forEach(([label, fn, cls]) => {
    const b = el('button', 'btn ' + (cls || ''), label);
    b.onclick = () => { closeOverlay(); fn(); };
    box.append(b);
  });
  o.append(box);
  o.classList.remove('hidden');
}
function closeOverlay() { $('#overlay').classList.add('hidden'); }

function openMenu() {
  openOverlay('<h2>Menu</h2>', [
    ['Riprendi', () => {}, 'main'],
    ['Nuova partita', () => { S = fresh(); save(); go('intro'); }],
  ]);
}

/* ---------- MOTORE SCENE ---------- */
function go(id) {
  if (id === 'reset') { S = fresh(); id = 'intro'; }
  if (id === 'map') return renderMap();
  S.scene = id;
  save();
  const sc = SCENES[id];
  renderHud();
  if (sc.type === 'forge') return renderForge(id, sc);
  if (sc.type === 'battle') return renderBattleIntro(id, sc);
  renderStory(id, sc);
}

function sceneBox(sc) {
  const stage = $('#stage');
  stage.innerHTML = '';
  const box = el('div', 'scene mood-' + (sc.mood || 'gold'));
  stage.append(box);
  stage.scrollTop = 0;
  return box;
}

function paragraphs(box, text) {
  text.split('\n\n').forEach(p => box.append(el('p', '', p)));
}

function resolveText(sc) { return typeof sc.text === 'function' ? sc.text(S) : sc.text; }

function renderStory(id, sc) {
  const box = sceneBox(sc);
  box.append(el('h2', '', sc.title));
  paragraphs(box, resolveText(sc));
  sc.choices.forEach(c => {
    const b = el('button', 'btn', c.t);
    b.onclick = () => {
      if (c.fx) c.fx(S);
      if (c.visit) S.visited[c.visit] = true;
      go(c.go);
    };
    box.append(b);
  });
}

/* ---------- MAPPA ---------- */
function renderMap() {
  S.scene = 'map';
  save();
  renderHud();
  const box = sceneBox({ mood: 'night' });
  box.append(el('h2', '', 'Beleriand · Mithrim'));
  box.append(el('p', '', 'I Noldor sbarcano sulla nuova terra. Prima dello scontro con le armate di Morgoth puoi esplorare e raccogliere materiali.'));
  MAP_NODES.forEach(n => {
    const done = !n.repeat && !n.final && S.visited[n.id];
    const b = el('button', 'btn node' + (done ? ' done' : ''), `<span>${n.name}<small>${n.desc}</small></span><span>${done ? '✓' : n.final ? '⚔' : '›'}</span>`);
    b.disabled = !!done;
    b.onclick = () => go(n.scene);
    box.append(b);
  });
  box.append(el('p', 'hint', 'I materiali opzionali potenziano il Silmaril. Dopo lo scontro finale la storia di Fëanor si chiude.'));
}

/* ---------- FORGIA ---------- */
function comboKey(a, b) { return [a, b].sort().join('+'); }

function calcFusion(a, b) {
  const A = MATERIALS[a], B = MATERIALS[b];
  const r = { atk: A.atk + B.atk, hp: A.hp + B.hp, mv: A.mv + B.mv, corr: A.corr + B.corr, combo: null };
  const c = COMBOS[comboKey(a, b)];
  if (c) { r.atk += c.atk; r.hp += c.hp; r.mv += c.mv; r.corr += c.corr; r.combo = c.n; }
  return r;
}

function renderForge(id, sc) {
  const picked = [];
  const draw = () => {
    const box = sceneBox(sc);
    box.append(el('h2', '', sc.title));
    paragraphs(box, resolveText(sc));
    const slots = el('div', 'slots');
    for (let i = 0; i < 2; i++) {
      const m = picked[i];
      const s = el('div', 'slot' + (m ? ' full' : ''), m ? MATERIALS[m].n : 'vuoto');
      if (m) s.onclick = () => { picked.splice(i, 1); draw(); };
      slots.append(s);
    }
    box.append(slots);
    const prev = el('div', 'preview');
    if (picked.length === 2) {
      const r = calcFusion(picked[0], picked[1]);
      prev.innerHTML = (r.combo ? `<b>${r.combo}</b><br>` : '') + `Silmaril: ⚔ +${r.atk} · ♥ +${r.hp} · ➜ +${r.mv}` + (r.corr ? ` · <span style="color:#e86a6a">Ombra +${r.corr}</span>` : '');
    } else prev.textContent = 'Tocca due materiali per vedere il risultato.';
    box.append(prev);
    const items = el('div', 'items');
    const ids = Object.keys(S.inv).filter(k => S.inv[k] > 0);
    ids.forEach(k => {
      const used = picked.filter(x => x === k).length;
      const left = S.inv[k] - used;
      const m = MATERIALS[k];
      const it = el('div', 'item' + (left <= 0 || picked.length >= 2 ? ' off' : ''), `<b>${m.n}</b> ×${left}<br>${m.d}`);
      it.onclick = () => { if (left > 0 && picked.length < 2) { picked.push(k); draw(); } };
      items.append(it);
    });
    if (!ids.length) items.append(el('p', 'hint', 'Non hai materiali.'));
    box.append(items);

    const fuse = el('button', 'btn main', 'Fondi nel Silmaril');
    fuse.disabled = picked.length < 2;
    fuse.onclick = () => {
      const r = calcFusion(picked[0], picked[1]);
      picked.forEach(k => { S.inv[k]--; });
      S.sil.atk += r.atk; S.sil.hp += r.hp; S.sil.mv += r.mv; S.corr += r.corr; S.forged++;
      save();
      picked.length = 0;
      renderHud();
      draw();
    };
    box.append(fuse);

    const cont = el('button', 'btn', 'Continua');
    if (sc.require && S.forged < 1) { cont.disabled = true; cont.textContent = 'Continua (forgia almeno una volta)'; }
    cont.onclick = () => go(sc.next);
    box.append(cont);
  };
  draw();
}

/* ---------- BATTAGLIA ---------- */
const W = 6, H = 7;
let bs = null;

function renderBattleIntro(id, sc) {
  const box = sceneBox(sc);
  box.append(el('h2', '', sc.title));
  paragraphs(box, sc.text);
  const b = el('button', 'btn main', 'Combattere');
  b.onclick = () => startBattle(id, sc);
  box.append(b);
  box.append(el('p', 'hint', 'Tocca un tuo personaggio per muoverlo, poi tocca un nemico a portata per attaccare.'));
}

function startBattle(id, sc) {
  const def = BATTLES[sc.battle];
  let uid = 0;
  const units = [];
  const mk = (k, x, y) => {
    const t = UT[k];
    const u = { id: uid++, k, name: t.name, g: t.g, team: t.team, hp: t.hp, atk: t.atk, mv: t.mv, rng: t.rng, boss: !!t.boss, x, y, state: 'ready' };
    if (k === 'feanor') { u.hp += S.sil.hp; u.atk += S.sil.atk; u.mv += S.sil.mv; }
    u.max = u.hp;
    units.push(u);
    return u;
  };
  mk('feanor', 2, 6); mk('maedhros', 3, 6); mk('celegorm', 1, 6);
  def.enemies.forEach(([k, x, y]) => mk(k, x, y));
  bs = { id, sc, def, units, rocks: def.rocks, turn: 1, sel: null, moves: new Map(), phase: 'player', over: false,
    log: 'Tocca Fëanor per iniziare.', mk, spawned: false };
  drawBattle();
}

const unitAt = (x, y) => bs.units.find(u => u.hp > 0 && u.x === x && u.y === y);
const isRock = (x, y) => bs.rocks.some(r => r[0] === x && r[1] === y);
const dist = (a, b) => Math.abs(a.x - b.x) + Math.abs(a.y - b.y);

function reachable(u) {
  const out = new Map([[u.x + ',' + u.y, 0]]);
  const q = [[u.x, u.y, 0]];
  while (q.length) {
    const [x, y, d] = q.shift();
    if (d >= u.mv) continue;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const nx = x + dx, ny = y + dy, k = nx + ',' + ny;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H || out.has(k) || isRock(nx, ny) || unitAt(nx, ny)) continue;
      out.set(k, d + 1);
      q.push([nx, ny, d + 1]);
    }
  }
  return out;
}

function say(t) { bs.log = t; const l = $('.blog'); if (l) l.textContent = t; }

function drawBattle() {
  const stage = $('#stage');
  stage.innerHTML = '';
  const box = el('div', 'scene mood-' + (bs.sc.mood || 'ash'));
  const cs = Math.floor(Math.min(window.innerWidth - 40, 420) / W);
  box.style.setProperty('--cs', cs + 'px');
  box.style.setProperty('--w', W);

  const s = bs.sel;
  const info = s
    ? `<b>${s.name}</b> · ♥ ${s.hp}/${s.max} · ⚔ ${s.atk} · ➜ ${s.mv} · portata ${s.rng}`
    : `Turno ${bs.turn} · ${bs.phase === 'player' ? 'tocca a te' : 'turno nemico'}`;
  box.append(el('div', 'binfo', info));

  const grid = el('div', 'grid');
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const c = el('div', 'cell');
    if (isRock(x, y)) c.classList.add('rock');
    if (bs.moves.has(x + ',' + y) && !unitAt(x, y)) c.classList.add('move');
    const u = unitAt(x, y);
    if (u) {
      if (s && s === u) c.classList.add('sel');
      if (s && u.team === 'e' && s.state !== 'done' && dist(s, u) <= s.rng) c.classList.add('atk');
      const ue = el('div', 'unit ' + u.team + (u.state === 'done' ? ' done' : '') + (u.boss ? ' boss' : ''), u.g);
      ue.append(el('div', 'hpbar', `<i style="width:${Math.max(0, Math.round(100 * u.hp / u.max))}%"></i>`));
      c.append(ue);
    }
    c.onclick = () => tap(x, y);
    grid.append(c);
  }
  box.append(grid);
  box.append(el('div', 'blog', bs.log));

  const bar = el('div', 'bbar');
  const wait = el('button', 'btn', 'Attendi');
  wait.onclick = waitUnit;
  const end = el('button', 'btn', 'Fine turno');
  end.onclick = () => { if (bs.phase === 'player' && !bs.over) endPlayerTurn(); };
  bar.append(wait, end);
  box.append(bar);
  stage.append(box);
}

function select(u) {
  bs.sel = u;
  bs.moves = u.state === 'ready' ? reachable(u) : new Map();
  drawBattle();
}

function tap(x, y) {
  if (bs.phase !== 'player' || bs.over) return;
  const u = unitAt(x, y);
  const s = bs.sel;
  if (u && u.team === 'p') {
    if (u.state === 'done') { say(u.name + ' ha già agito.'); return; }
    select(u); return;
  }
  if (!s) { say('Seleziona prima uno dei tuoi.'); return; }
  if (u && u.team === 'e') {
    if (s.state !== 'done' && dist(s, u) <= s.rng) attack(s, u);
    else say('Fuori portata.');
    return;
  }
  if (!u && s.state === 'ready' && bs.moves.has(x + ',' + y)) {
    s.x = x; s.y = y; s.state = 'moved';
    bs.moves = new Map();
    const anyHit = bs.units.some(e => e.team === 'e' && e.hp > 0 && dist(s, e) <= s.rng);
    say(anyHit ? 'Ora attacca un nemico, oppure attendi.' : 'Nessun nemico a portata: attendi.');
    drawBattle();
  }
}

function waitUnit() {
  if (bs.phase !== 'player' || bs.over || !bs.sel) return;
  bs.sel.state = 'done';
  bs.sel = null; bs.moves = new Map();
  afterAction();
}

function attack(a, d) {
  d.hp -= a.atk;
  say(`${a.name} colpisce ${d.name} (−${a.atk}).` + (d.hp <= 0 ? ` ${d.name} cade.` : ''));
  a.state = 'done';
  bs.sel = null; bs.moves = new Map();
  afterAction();
}

function afterAction() {
  if (checkEnd()) return;
  if (bs.units.filter(u => u.team === 'p' && u.hp > 0).every(u => u.state === 'done')) endPlayerTurn();
  else drawBattle();
}

function checkEnd() {
  if (bs.over) return true;
  const f = bs.units.find(u => u.k === 'feanor');
  const foes = bs.units.filter(u => u.team === 'e' && u.hp > 0);
  const gothmog = bs.units.find(u => u.k === 'gothmog');
  if (f.hp <= 0) {
    bs.over = true;
    if (bs.def.finale) { drawBattle(); setTimeout(() => go('morte'), 700); }
    else openOverlay('<h2>Sconfitta</h2><p>Fëanor è caduto. Le sue ceneri non possono ancora raccontare la storia.</p>',
      [['Riprovare', () => startBattle(bs.id, bs.sc), 'main']]);
    return true;
  }
  if (bs.def.finale) {
    if (gothmog && gothmog.hp <= 0) {
      bs.over = true; S.flags.gothmog = true; drawBattle();
      setTimeout(() => go('morte'), 700);
      return true;
    }
    if (!foes.length && !bs.spawned) spawnGothmog();
    return false;
  }
  if (!foes.length) {
    bs.over = true;
    let rewardText = '';
    if (bs.def.reward) {
      S.inv[bs.def.reward] = (S.inv[bs.def.reward] || 0) + 1;
      rewardText = `<p>Ottieni: <b>${MATERIALS[bs.def.reward].n}</b>.</p>`;
    }
    if (bs.sc.visit) S.visited[bs.sc.visit] = true;
    save();
    openOverlay('<h2>Vittoria</h2>' + rewardText, [['Continua', () => go(bs.sc.win), 'main']]);
    return true;
  }
  return false;
}

function spawnGothmog() {
  bs.spawned = true;
  const spots = [[3, 0], [2, 0], [4, 0], [3, 1], [1, 0], [5, 0]];
  const sp = spots.find(([x, y]) => !unitAt(x, y) && !isRock(x, y));
  if (!sp) return;
  bs.mk('gothmog', sp[0], sp[1]);
  say('Gothmog, Signore dei Balrog, scende in battaglia.');
}

async function endPlayerTurn() {
  if (bs.phase !== 'player' || bs.over) return;
  bs.phase = 'enemy'; bs.sel = null; bs.moves = new Map();
  drawBattle();
  await sleep(300);
  const enemies = bs.units.filter(u => u.team === 'e' && u.hp > 0);
  for (const e of enemies) {
    if (e.hp <= 0 || bs.over) continue;
    const players = bs.units.filter(u => u.team === 'p' && u.hp > 0);
    if (!players.length) break;
    const tgt = players.reduce((m, p) => (dist(e, p) < dist(e, m) ? p : m), players[0]);
    if (dist(e, tgt) > e.rng) {
      let best = null, bd = 1e9;
      for (const [k] of reachable(e)) {
        const [x, y] = k.split(',').map(Number);
        const d = Math.abs(x - tgt.x) + Math.abs(y - tgt.y);
        if (d < bd) { bd = d; best = [x, y]; }
      }
      if (best && (best[0] !== e.x || best[1] !== e.y)) { e.x = best[0]; e.y = best[1]; drawBattle(); await sleep(280); }
    }
    const inr = players.filter(p => dist(e, p) <= e.rng).sort((a, b) => a.hp - b.hp);
    if (inr.length) {
      const p = inr[0];
      p.hp -= e.atk;
      say(`${e.name} colpisce ${p.name} (−${e.atk}).` + (p.hp <= 0 ? ` ${p.name} cade.` : ''));
      drawBattle();
      await sleep(320);
      if (checkEnd()) return;
    }
  }
  if (bs.over) return;
  bs.turn++;
  if (bs.def.finale && !bs.spawned && bs.turn >= 4) spawnGothmog();
  bs.units.forEach(u => { if (u.team === 'p' && u.hp > 0) u.state = 'ready'; });
  bs.phase = 'player';
  say('Nuovo turno.');
  drawBattle();
}

/* ---------- AVVIO ---------- */
window.addEventListener('DOMContentLoaded', () => {
  if (S.scene === 'map') renderMap(); else go(SCENES[S.scene] ? S.scene : 'intro');
});
