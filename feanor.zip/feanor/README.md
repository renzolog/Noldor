# Il Giuramento di Fëanor

Prototipo: narrativa a scelte, forgia dei Silmaril, battaglie a turni su griglia, mappa a nodi.
HTML5 in `www/`, impacchettato con Capacitor.

- Test rapido: apri `www/index.html` nel browser (vista telefono).
- APK: carica il progetto su GitHub (branch `main`); il workflow `Build APK` produce `feanor-debug-apk`.
- I dati di gioco (scene, materiali, battaglie) sono in cima a `www/game.js`.
